#ifndef RANDOM_H_
#define RANDOM_H_

void init_gerador_random(void);

int numero_random(int min, int max);

#endif