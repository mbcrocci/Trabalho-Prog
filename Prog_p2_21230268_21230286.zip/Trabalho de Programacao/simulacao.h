#ifndef SIMULACAO_H_
#define SIMULACAO_H_
#include "config.h"

Configuracoes Standard(int *falha);
void simul(Configuracoes C, int PrimVez, int passo);
void simul_passo(Configuracoes C, int PrimVez);

#endif

